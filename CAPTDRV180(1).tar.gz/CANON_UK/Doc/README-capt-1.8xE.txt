=================================================================================
Canon CAPT Printer Driver for Linux Version 1.80

PLEASE READ THIS DOCUMENT CAREFULLY
=================================================================================


---------------------------------------------------------------------------------
Trademarks

Adobe, Acrobat, Acrobat Reader, PostScript and PostScript 3 are trademarks of
Adobe Systems Incorporated.
Linux is a trademark of Linus Torvalds.
HP-GL is a trademark of Hewlett-Packard Company.
UNIX is a trademark of The Open Group in the United States and other countries.
Other product and company names herein may be the trademarks of their respective
owners.
---------------------------------------------------------------------------------


---------------------------------------------------------------------------------
CONTENTS

Before Starting
1. Introduction
2. Distribution File Structure of the Canon CAPT Printer Driver for Linux
3. Hardware Requirements
4. Auto startup setting procedure for ccpd daemon
5. Cautions, Limitations, and Restrictions
---------------------------------------------------------------------------------


1. Introduction -----------------------------------------------------------------
Thank you for using the Canon CAPT Printer Driver for Linux. This CAPT printer
driver provides printing functions for Canon LBP printers operating under
the CUPS (Common UNIX Printing System) environment, a printing system that
operates on Linux operating systems.


2. Distribution File Structure of the Canon CAPT Printer Driver for Linux -------
The Canon CAPT Printer Driver for Linux distribution files are as follows:
Furthermore, the file name for the CUPS driver common module and printer
driver module differs depending on the version.

- README-capt-1.8xE.txt (This document)
Describes supplementary information on the Canon CAPT Printer Driver for Linux.

- LICENSE-captdrv-1.8xE.txt
Describes User License Agreement on the Canon CAPT Printer Driver for Linux.

- guide-capt-1.8xE.tar.gz
Online manual that explains how to use the Canon CAPT Printer Driver for Linux.
This includes the system requirements, installation, and usage of the Canon CAPT
Printer Driver for Linux.
Because this file is in a compressed format, you need to extract it to the
appropriate directory before reading.

- cndrvcups-common-1.80-x.i386.rpm
- cndrvcups-common_1.80-x_i386.deb
Installation package for the CUPS driver common module used by the Canon CAPT
Printer Driver for Linux.

- cndrvcups-capt-1.80-x.i386.rpm
- cndrvcups-capt_1.80-x_i386.deb
Installation package for the Canon CAPT Printer Driver for Linux.

- cndrvcups-common-1.80-x.tar.gz
Source file for the CUPS driver common module used by the Canon CAPT Printer
Driver for Linux.

- cndrvcups-capt-1.80-x.tar.gz
Source file for the Canon CAPT Printer Driver for Linux.


3. Hardware Requirements --------------------------------------------------------
This printer driver can be used with the following hardware environment.

Hardware:
    Computer that is enable to operate Linux, with x86 compatible CPU (32-bit)

Object Printer:
    LBP3010/LBP3018/LBP3050
    LBP3100/LBP3108/LBP3150
    LBP3250
    LBP3310
    LBP5100
    LBP5300
    LBP3500
    LBP3300
    LBP5000
    LBP3210
    LBP3000
    LBP2900
    LBP3200
    LBP-1120
    LBP-1210


Please see the online manual about the install method and the concrete usage.


4. Auto startup setting procedure for ccpd daemon -------------------------------
When setting the Status Monitor to start automatically, ccpd daemon must be set
to start automatically as well.
Set ccpd daemon to start automatically in the following procedure.

<For a distribution with a /etc/rc.local file>
Log in as 'root' and add the '/etc/init.d/ccpd start' command to the
/etc/rc.local file.

<For a distribution with a /sbin/insserv command>
Log in as 'root', add the following comments to the third line in
/etc/init.d/ccpd, and execute the 'insserv ccpd' command.

### BEGIN INIT INFO
# Provides:          ccpd
# Required-Start:    $local_fs $remote_fs $syslog $network $named
# Should-Start:      $ALL
# Required-Stop:     $syslog $remote_fs
# Default-Start:     3 5
# Default-Stop:      0 1 2 6
# Description:       Start Canon Printer Daemon for CUPS
### END INIT INFO


5. Cautions, Limitations, and Restrictions --------------------------------------

- Ghostscript which includes common API is required to use this printer driver.
  Make sure to install Ghostscript before installing this printer driver.
  Refer to the following URL to find out how to get Ghostscript.
  http://opfc.sourceforge.jp/index.html.en

- If you install "cndrvcups-common" package version 1.80, make sure you install
  the same version of the "cndrvcups-capt" package, i.e. 1.80.

- When specifying multiple pages/copies for [Pages per sheet] in the [General]
  sheet to print a document created with StarSuite7/OpenOffice, due to a cause
  of operation by the CUPS module, settings are not correctly assigned to the
  multiple pages and output.

- PostScript files created with the number of copies specified in OpenOffice.org
  or StarSuite are affected not by the value specified by [Number of copies] in
  the [cngplp] dialog box (the driver UI), but by the number of copies set when
  creating the PostScript file.

- If settings are changed from the driver UI, during print processing, the
  printed result will reflect the changed settings.

- If [Brightness and Gamma] is specified in the [General] sheet from an
  application such as OpenOffice.org, GIMP, or Acrobat Reader v.5.0, the settings
  will be invalid.

- If you set [Filter] to [HP-GL/2 options] in the [Filter] sheet of the printer
  driver screen, due to a cause of operation by the CUPS module, the [Pen width]
  setting is invalid.

- You cannot print a PDF document by directly specifying it from the desktop or
  command line. When printing a PDF document, it is recommended that you print
  it from Acrobat Reader or Adobe Reader.

- The maximum number of files that can be held in the print queue when printing
  is 500 according to CUPS specifications. Files queued after the 500th file will
  be ignored.

- When the paper size is specified from the application, the specified contents
  will not be valid. The value specified for [Paper Size] in the [General] sheet
  in the printer driver screen will be reflected when printing.

- If you are using SUSE LINUX Professional 9.3, the driver UI may display
  unintelligible characters. You can solve this problem using the following
  method.
  1) Log in as 'root'.
  2) Execute the following command to change the GTK+ environment settings.
     # cd /etc/
     # ln -s opt/gnome/gtk ./

- If you are using SUSE LINUX Professional 9.3, a warning may occur when you
  activate the driver UI. You can solve this problem using the following
  method.
  1) Open [K Menu] -> [Control Center].
  2) Select [Appearance & Themes].
  3) Select [Colors].
  4) Deselect [Apply colors to non-KDE applications].
  5) Close [Control Center].

- If you are using LBP3010, LBP3018, LBP3050, LBP3100, LBP3108, LBP3150,
  LBP3250, LBP3310, LBP5100, LBP5300, LBP3500, LBP3300 or LBP5000, blank paper
  is not output according to Glue Code specifications, even if the print job
  includes blank pages.
  The setting does not become effective even after setting [Use Skip Blank
  Pages Mode] in the [Finishing] sheet to [Off] or specifying the printer
  setting not to use the Skip Blank Pages mode from the command line.

- If you are using LBP3500, LBP3300 or LBP5000 with NB-C1 installed in a network
  environment, the version of the firmware of the network board needs to be 1.30
  or later, otherwise the network board does not operate properly.
  Download the latest update file from the Canon website and update the firmware.

- If you are using LBP5300 in a network environment, the version of the firmware
  of the network board needs to be 1.10 or later, otherwise the network board
  does not operate properly.
  Download the latest update file from the Canon website and update the firmware.

- If you are using LBP3310 with NB-C2 installed in a network environment, the
  version of the firmware of the network board needs to be 1.30 or later,
  otherwise the network board may not operate properly. Download the latest
  update file from the Canon website and update the firmware.

- If you use the Cancel Job key on the printer unit to cancel jobs, the jobs from
  CUPS may not be cleared depending on the data size. In this case, delete the
  jobs using the CUPS interface.

- If you cannot browse the IP address of localhost, you cannot start Status
  Monitor.
  Modify "/etc/hosts" so that you can browse the IP address of localhost.

- If you have connected the printer using a USB cable in the environment in which
  the HAL daemon runs on Fedora Core, delete the registered printer entry created
  by the HAL daemon with the printer name once, and then perform the registration
  operation for the printer.

- If you are using CUPS 1.2.x for the printing system, the printer may not
  operate properly when printing banner pages.
  Before you print banner pages, replace the printing system with CUPS 1.1.x.

- If you are using the following distributions, you may not be able to install
  the printer driver successfully because "libstdc++.so.5" is not installed by
  default.
  In this case, perform the additional installation of the package.
  - For Fedora Core 4, Fedora Core 5, Fedora Core 6, Fedora 7, Fedora 8, and
    RedHat Enterprise Linux 5.1
    -> Install the package (compat-libstdc++-33).
  - For Ubuntu 7.10 and Debian GNU/Linux 4.0
    -> Obtain the package (gcc-3.3-base or libstdc++5) from
       "http://lug.mtu.edu/ubuntu/pool/main/g/gcc-3.3/" to install it.
       Reference Information: http://ubuntuforums.org/showthread.php?t=674100
  - For Mandriva 2008
    -> Obtain the package (libstdc++5) from the standard mirror server etc. to
       install it.

- If you are using SUSE Linux 9.3 or SUSE Linux 10.0, and are printing from
  the [Print] dialog box of Mozilla or FireFox, because the multiple copies
  setting is not enabled, you can print only one copy regardless of how many
  copies you have specified.
  This problem can be solved by changing the following line in the file
  "/etc/cups/mime.convs".
  [Before change]
    application/mozilla-ps application/postscript 33 pswrite
  [After change]
    application/mozilla-ps application/postscript 33 pstops

- If you are using Fedora Core 5 or later, when SELinux is set to Enforcing or
  Permissive, you cannot print with the default settings.  You can enable
  printing by changing the settings as follows.
  1) Open System menu ->[Administration] ->[Security Level and Firewall].
  2) Select [SELinux]tab ->[Modify SELinux Policy] ->[Printing].
  3) Check the 4 check boxes under [Printing].
  4) Click [OK] to close the window.

- If you are using Fedora 7 or later, and if SELinux is set to Enforce, you need
  to install a policy package using the following method. (You do not need to
  install a policy package if Permissive is specified.)
  <Preparation>
    1) Install the printer driver package, then specify the settings for the
       printer.
       * Please see the online manual about the install method and the setting
         method.
    2) Check if the checkpolicy package is installed.
         # rpm -qa | grep checkpolicy
       If the package name is not displayed, install the package using the
       following command.
         # yum install checkpolicy
    3) Set SELinux to Enforcing.
       1. From the menu bar, select [System] - [Administration] - [SELinux
          Management].
       2. In the dialog box, set [System Default Enforcing Mode] to [Enforcing],
          and then click [OK].
    4) Restart Linux.
  <Creating and installing a policy package>
    1) Set SELinux to Permissive.
         # /usr/sbin/setenforce 0
    2) Print to the object printer.
       Example: Printing the CUPS text document to LBPxxxx
         # lpr -P LBPxxxx /usr/share/cups/data/testprint.ps
    3) Create a policy package.
         # audit2allow -M cncapt -l -i /var/log/audit/audit.log
    4) Install the policy package.
         # /usr/sbin/semodule -i cncapt.pp
    5) Restart Linux.

- When performing banner printing in Fedora 8 or Fedora 9, if you specify a
  setting other than [none] for [End] under [Banner] in the [General] sheet, the
  print queue will stop.

- If you are using Fedora 9, restarting the CCPD daemon may stop the kernel.
  You can avoid this problem by updating the kernel to
  "kernel-2.6.25.14-108.fc9".

- If you are using OpenSUSE 10.2 or SLED10SP1, which includes Ghostscript
  version 8.15.3, you may not be able to print some documents. To solve this
  problem, install another version of Ghostscript.

- If you are using OpenSUSE 11.0 with Ghostscript version 8.6.x, printing from
  Evince, GIMP, or other applications may take time.

- If you are using Adobe Reader 7.0.x, and modify such settings as Paper Size,
  Paper Source, Duplex Printing, etc. in the print dialog window, these options
  are automatically added to the printer command. However, these settings will
  not work because they cannot be recognized as command options. To solve this
  problem, use "-o" to separate each command options.
     [before] -o InputSlot=Manual,Duplex=DuplexNotumble
     [after]  -o InputSlot=Manual -o Duplex=DuplexNoTumble

- When printing PDF files using Adobe Reader 8, there may be instances where
  some image data is not printed.
  This problem can be avoided by using Adobe Reader 7.

- When performing 2-sided printing with Adobe Reader 8.1.2, if you specify
  [ON (Short-edged Binding)] for [Duplex Printing] in the print properties for
  Adobe Reader 8.1.2, the document will be printed on both sides with long-edged
  binding.
  This problem can be avoided by printing the document using the cngplp command
  from the command line.

- If you are using Vine Linux 3.1, you may take time to print from Adobe Reader
  7.0.9 or may not be able to print some documents.

- When printing PDF files containing Japanese characters from the command line
  in Vine Linux 4.1, there may be instances where Ghostscript terminates 
  unexpectedly, causing printing to stop.
  This problem can be avoided by printing PDF files using Adobe Reader.

- When printing PDF files from Adobe Reader 8 in Vine Linux 4.1, there may be 
  instances where Ghostscript terminates unexpectedly, causing the print queue 
  to stop.
  This is caused by Ghostscript (7.07) not being able to analyze PS files 
  created by Adobe Reader 8, and consequently terminating prematurely, thereby 
  stopping the filtering process.
  This problem can be avoided by using Adobe Reader 7.

- When printing text files in landscape orientation in Vine Linux 4.1, Vine Linux
  4.2, Fedora 8, Fedora 9, or RedHat Enterprise Linux v.5, there may be instances
  where the text file is printed in portrait orientation with some of the print
  data not being printed on the page. This is caused by the CUPS filter employed
  by the distribution you are using creating a PS command that is already set to
  portrait.
  Also, some of the functions provided in the CUPS standard filter "texttops"
  may not operate correctly.
  This problem can be avoided by changing the CUPS filter name specified in the
  "text/plain" entry line in the CUPS setting file "mime.convs" to the CUPS
  standard filter "texttops". This will result in Japanese characters being
  misprinted, therefore when printing Japanese characters, a PS command must
  first be created using a text editor or text-Postscript conversion program such
  as paps.

- If you specify Paper Source settings in the print dialog of an application
  such as Writer of OpenOffice.org, the settings made from the application are
  overridden by the printer driver UI settings. To print from the desired
  Paper Source, specify the Paper Source from the printer driver UI beforehand,
  or print from the command line.

- If you are using Debian GNU/Linux 4.0, a PPD file error may occour when you
  register the printer (PPD) with the print spooler. To solve this problem,
  use "-P (full path to the ppd)" instead of "-m" when you specify the ppd
  using the command line.
    Example: /usr/sbin/lpadmin -p LBP5000
              -P /usr/share/cups/model/CNCUPSLBP5000CAPTK.ppd
              -v ccp:/var/ccpd/fifo0 -E

- If you are using Ubuntu7.10, you may fail to print because it introduces
  security software called AppArmor.
  As the workaround, disable the AppArmor CUPS profile by running
  sudo aa-complain cupsd to enable printing.
  For more details, see Ubuntu7.10 Release Notes.

- When printing PDF files from Adobe Reader in Mandriva, regardless of the
  version being used, there may be instances where Ghostscript terminates 
  unexpectedly, causing the print queue to stop.
  This is caused by Ghostscript (8.60) not being able to analyze PS commands 
  created using PS files for which security settings have been specified, and 
  consequently terminating prematurely, thereby stopping the filtering process.
  This problem can be avoided by not printing PDF files that have security 
  settings using Adobe Reader.

- If you are using Mandriva One 2008 Spring with CUPS version 1.3.6, unintended
  print results may occur even when printing with standard CUPS print functions.
  This problem can be solved by updating CUPS.

- If you want to use multiple printers with the same device path (such as
  /dev/usb/lp0) on a USB connection, exit the ccpd daemon, and then add a
  printer when you switch the connection.
  If you do not exit the ccpd daemon, you may not be able to obtain appropriate
  printout results.

- If 15 or more characters are specified for the host name of Linux, the printer
  status may not display properly in Status Monitor.

- If you are using printers of the same model with one computer, and one is
  connected via USB and another is connected via network, the printer status may
  not display properly in Status Monitor.

- If your version of Ghostscript is 8.6x, you may not be able to print some
  documents.


=================================================================================
Support
=================================================================================
This Software and Related Information are independently developed by Canon and
distributed by Canon local company. Canon as manufacturer of printers supporting
the Software and Related Information ("Canon Printers"), and Canon local company
as selling agency of Canon Printers, do not receive any user support call and
/or request or any requests for information about the Software and Related
Information. Any demand for information about Canon Printers including
information about the repair and supplies for Canon Printers should be directed 
to Canon local company.
=================================================================================
                                                        Copyright CANON INC. 2008
